# OH MYGAJI!! — Berapa Jer Tinggal?

Responsive Malay-language salary insight prototype by arsolution.co.

## Publish with GitHub Pages
1. Create a public repository named `oh-my-gaji`.
2. Upload `index.html` and `README.md` to the repository root.
3. Open Settings → Pages.
4. Select Deploy from a branch → `main` → `/ (root)` → Save.

## Important calculation notes
This build is an interactive prototype. EPF, PERKESO and EIS values use simplified estimates and are not a substitute for the official contribution tables. PCB is entered by the user from their payslip; this version does not calculate official PCB. Tax relief cards are an organizer for selected YA 2026 / YA 2025 categories and do not determine final chargeable income or tax payable. Validate eligibility, sub-limits and documentation against current HASiL guidance.
